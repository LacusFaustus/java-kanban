package ru.yandex.javacourse.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.yandex.javacourse.model.Task;
import static org.junit.jupiter.api.Assertions.*;

class InMemoryHistoryManagerTest {
    private static final String TASK_NAME = "Test Task";
    private static final String TASK_DESCRIPTION = "Test Description";

    private HistoryManager historyManager;
    private Task task;

    @BeforeEach
    void setUp() {
        historyManager = new InMemoryHistoryManager();
        task = new Task(TASK_NAME, TASK_DESCRIPTION);
    }

    @Test
    @DisplayName("History should be empty when no tasks viewed")
    void getHistory_shouldReturnEmptyList_whenNoTasksViewed() {
        assertTrue(historyManager.getHistory().isEmpty());
    }

    @Test
    @DisplayName("History should contain task after it was added")
    void add_shouldAddTaskToHistory_whenTaskAdded() {
        historyManager.add(task);
        assertEquals(1, historyManager.getHistory().size());
        assertEquals(task, historyManager.getHistory().get(0));
    }
    @Test
    @DisplayName("Adding null task should not affect history")
    void add_shouldHandleNull_whenNullTaskAdded() {
        historyManager.add(null);
        assertTrue(historyManager.getHistory().isEmpty());
    }
    @Test
    @DisplayName("History should not exceed maximum size")
    void add_shouldLimitHistorySize_whenMaxSizeReached() {
        // Добавляем больше задач, чем максимальный размер истории
        for (int i = 0; i < 15; i++) {
            Task newTask = new Task(TASK_NAME + i, TASK_DESCRIPTION);
            historyManager.add(newTask);
        }
        assertEquals(10, historyManager.getHistory().size());
    }

    @Test
    @DisplayName("Adding the same task multiple times should keep it once in history")
    void add_shouldNotDuplicateTask_whenSameTaskAddedMultipleTimes() {
        historyManager.add(task);
        historyManager.add(task);
        historyManager.add(task);

        assertEquals(1, historyManager.getHistory().size());
    }
}