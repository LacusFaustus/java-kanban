package ru.yandex.javacourse.model;

public enum Status {
    NEW,
    IN_PROGRESS,
    DONE
}